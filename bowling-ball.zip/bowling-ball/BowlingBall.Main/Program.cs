﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BowlingBall.Main
{
    class Program
    {
        //Input to be passed
        //    10
        //    10
        //    9 1
        //    5 5
        //    7 2
        //    10
        //    10
        //    10
        //    9 0
        //    8 2
        //    9 1 10

        static void Main(string[] args)
        {
            int frames = Convert.ToInt32(Console.ReadLine());
            for(int i = 0; i < frames; i++)
            {
                string[] rolls = Console.ReadLine().Split();
                List<int> lstRolls = new List<int>();
                foreach(var roll in rolls)
                {
                    lstRolls.Add(Convert.ToInt32(roll));
                }
                Game.Roll(lstRolls);
            }
            Console.WriteLine(Game.GetScore());
        }
    }
}
