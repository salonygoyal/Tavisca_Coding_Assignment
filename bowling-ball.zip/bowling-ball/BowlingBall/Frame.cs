﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BowlingBall
{
    public class Frame
    {
        private int frameNo;
        private int score;
        private List<int> rollsCount;
        private bool isSpare = false;
        private bool isStrike = false;

        public Frame()
        {
            rollsCount = new List<int>();
        }

        public int FrameNo { get; set; }
        public int Score { get; set; }
        public bool IsSpare { get; set; }
        public bool IsStrike { get; set; }
        public List<int> RollsCount {
            get
            {
                return rollsCount;
            }
        }

        public void AddRolls(int rolls)
        {
            RollsCount.Add(rolls);
        }
    }
}
