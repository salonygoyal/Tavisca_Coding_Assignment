﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BowlingBall
{
    public static class Game
    {
        private static int frameNo;

        private static Frames totalFrames;
        static Game()
        {
            frameNo = 1;
            totalFrames = new Frames();
        }

        public static List<Frame> TotalFrames { get { return totalFrames.LstFrames; } }
        public static void Roll(List<int> pins)
        {
            // Add your logic here. Add classes as needed.
            Frame frame = new Frame();
            frame.FrameNo = frameNo;
            foreach(int pin in pins)
            {
                frame.AddRolls(pin);
            }
            if(pins.Count == 1 && pins[0] == 10)
            {
                frame.IsStrike = true;
                frame.Score = 10;
            }
            else if(pins.Count == 2)
            {
                if(pins[0] + pins[1] == 10)
                {
                    frame.IsSpare = true;
                    frame.Score = 10;
                }
                else
                {
                    frame.Score = pins[0] + pins[1];
                }
            }
            else if(pins.Count == 3)
            {
                frame.Score = pins[0] + pins[1] + pins[2];
            }
            totalFrames.LstFrames.Add(frame);
            frameNo++;
        }

        public static int GetScore()
        {
            // Returns the final score of the game.
            int totalScore = 0;
            int countOfFrames = TotalFrames.Count;
            for(int i=0; i < countOfFrames; i++)
            {
                if(TotalFrames[i].IsStrike && (i + 1) < countOfFrames && TotalFrames[i+1].IsSpare)
                {
                    totalScore += TotalFrames[i].Score + TotalFrames[i + 1].Score;
                }
                else if (TotalFrames[i].IsStrike && (i + 1) < countOfFrames && TotalFrames[i + 1].IsStrike && (i + 2) < countOfFrames && TotalFrames[i + 2].IsStrike)
                {
                    totalScore += TotalFrames[i].Score + TotalFrames[i + 1].Score + TotalFrames[i + 2].Score;
                }
                else if (TotalFrames[i].IsStrike && (i + 1) < countOfFrames && TotalFrames[i + 1].IsStrike && (i + 2) < countOfFrames && TotalFrames[i + 2].IsSpare)
                {
                    totalScore += TotalFrames[i].Score + TotalFrames[i + 1].Score + TotalFrames[i + 2].RollsCount[0];
                }
                else if(TotalFrames[i].IsStrike && (i + 1) < countOfFrames && !TotalFrames[i + 1].IsStrike && !TotalFrames[i + 1].IsSpare)
                {
                    totalScore += TotalFrames[i].Score + TotalFrames[i + 1].Score;
                }
                else if(TotalFrames[i].IsStrike && (i + 1) < countOfFrames && TotalFrames[i + 1].IsStrike && (i + 2) < countOfFrames && !TotalFrames[i + 2].IsStrike && !TotalFrames[i + 2].IsSpare)
                {
                    totalScore += TotalFrames[i].Score + TotalFrames[i + 1].Score + TotalFrames[i + 2].RollsCount[0];
                }
                else if(TotalFrames[i].IsSpare && (i + 1) < countOfFrames)
                {
                    totalScore += TotalFrames[i].Score + TotalFrames[i+1].RollsCount[0];
                }
                else if(!TotalFrames[i].IsStrike && !TotalFrames[i].IsSpare)
                {
                    totalScore += TotalFrames[i].Score;
                }
                else if( i == (countOfFrames - 1))
                {
                    totalScore += TotalFrames[i].Score;
                }
            }
            return totalScore;
        }
    }
}
