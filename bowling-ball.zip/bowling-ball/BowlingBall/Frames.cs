﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BowlingBall
{
    public class Frames
    {
        private List<Frame> lstFrames;

        public Frames()
        {
            lstFrames = new List<Frame>();
        }

        public List<Frame> LstFrames
        {
            get
            {
                return lstFrames;
            }
        }
    }
}
